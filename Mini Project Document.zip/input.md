![](./image3.jfif){width="2.0137751531058616in"
height="0.757985564304462in"}

![Double Tap Gesture
outline](./image4.png){width="0.24166666666666667in"
height="0.24166666666666667in"}**1. Introduction**

In the era of digital streaming, understanding content performance is
crucial for strategic decision-making. This project presents a
comprehensive analysis of Disney+ content using data visualization
techniques. The primary aim is to extract meaningful insights related to
content quality, audience engagement, and distribution trends through an
interactive dashboard.

The project leverages data preprocessing techniques and business
intelligence tools to transform raw data into actionable insights.

**2. Objectives**

The key objectives of this project are:

-   To analyse the distribution of content across genres, years, and
    regions

-   To evaluate content quality using IMDb ratings

-   To measure audience engagement using IMDb votes

-   To identify top-performing titles

-   To compare quality versus popularity trends

-   To design an interactive and user-friendly dashboard

**3. Dataset Description**

The dataset consists of Disney+ content information with the following
attributes:

\* Title

\* Genre

\* Release Year

\* IMDb Rating

\* IMDb Votes

\* Runtime

\* Country

\* Cast (Actors)

The dataset provides both quantitative and categorical data, enabling
multi-dimensional analysis.

![Arrow circle with solid
fill](./image6.png){width="0.23333333333333334in"
height="0.23333333333333334in"} **4. Data Preprocessing**

Data preprocessing was performed using Excel to ensure data quality and
consistency.

Key Steps:

\* Removal of duplicate records

\* Handling missing or inconsistent values

\* Standardization of column names

\* Conversion of runtime into numerical format

\* Creation of derived columns:like;

\* Movie Era (based on release year)

\* Rating Level (High, Medium, Low)

\* Meta score Category

\* Quality vs Popularity classification

These steps ensured that the dataset was clean, structured, and ready
for analysis.

![Bar chart with solid
fill](./image8.png){width="0.35833333333333334in"
height="0.3048512685914261in"}**5. Data Modelling & Transformation**

The cleaned dataset was imported into Power BI, where further
transformations and modelling were performed.

Key Activities:

\* Establishing relationships

\* Creating calculated columns

\* Developing DAX measures for KPIs

\* Ensuring proper data types and formatting

**6. Key Performance Indicators (KPIs)**

The following KPIs were developed to summarize the dataset:

-   Total Titles -- Total number of unique content items

-   Average IMDb Rating -- Indicator of overall content quality

-   Total IMDb Votes-- Measure of audience engagement

-   Average Runtime -- Average duration of content

-   Hit Ratio (%) -- Percentage of high-performing ("Super Hit") titles

**📈 7. Dashboard Design & Structure**

The dashboard is structured into four main sections to ensure logical
flow and usability.

7.1 Executive Summary

Provides a high-level overview of the dataset

Visuals Used:

\* KPI Cards

\* Genre Distribution (Bar Chart)

\* Rating Level Distribution (Donut Chart)

\* Year-wise Trend (Line Chart)

🟩 7.2 Content Insights

Focuses on performance comparison across genres and popularity.

Visuals Used:

-   Scatter Plot (IMDb Rating vs Votes)

-   Genre vs Average Rating (Bar Chart)

-   Tree map (Genre Distribution)

-   Stacked Column Chart

7.3 Trends & Evolution

Analyses temporal patterns in content production and quality.

Visuals.

\* Titles by Year (Line Chart)

\* Average Rating by Year (Line Chart)

\* Genre Trends Over Time (Area Chart)

7.4 Title Deep Dive

Provides detailed insights for individual titles.

Used;

\* Drill-through functionality

\* Detailed KPI Cards (Rating, Votes, Runtime)

\* Additional metadata (Genre, Country, Cast)

**8. Interactivity & Advanced Features**

To enhance user experience and analytical depth, the following features
were implemented:

***Slicers*** for dynamic filtering (Genre, Year, Country)

***Drill-through pages*** for detailed analysis

Interactive visuals enabling cross-filter

**9. DAX Measures**

Custom DAX measures were created to support analysis.

Example: Hit Ratio

Calculated as the proportion of "Super Hit" titles to total unique
titles, ensuring duplicates do not affect results.

Other measures include:

\* Total Titles

\* Average Rating

\* Total Votes

![Hourglass 90% with solid fill](./image10.png){width="0.325in"
height="0.18145778652668418in"} **10. Key Insights**

The analysis revealed several important insights:

-   High ratings do not always correlate with high audience engagement

-   Certain genres consistently dominate content distribution

-   Content production has increased significantly in recent years

-   A small proportion of titles contribute to the majority of high
    performance

**12. Conclusion**

This project demonstrates the effective use of data analytics and
visualization techniques to extract insights from streaming platform
data. The dashboard enables users to explore content trends, evaluate
performance, and make informed decisions.

It highlights proficiency in data preprocessing, data modelling, DAX,
and interactive dashboard design.
